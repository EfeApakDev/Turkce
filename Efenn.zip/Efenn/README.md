# Dahi Anlamındaki De

İlk 3 günde yaklaşık 1.5 milyon kişinin ziyaret ettiği, viral olmuş bir web sitesi.

https://dahianlamindaki.de 